package backend.repository;

public class UserRepository {
    
}
